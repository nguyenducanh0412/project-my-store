# MyStore

Description of Project:
- View list product and view detail product
- Add item to cart
- Checkout product in cart (using reactive form validate form)
- Delete product in cart
- Route (using lazy loading module)


## Running
### Install Dependencies 
You can install dependencies using the following steps:
```
npm install
```

## Start server
On the same terminal, run the command 
```
ng serve
```
The project will be started on localhost:4200