export interface IProduct {
  id: number;
  name: string;
  price: number;
  url: string;
  description: string;
  quantity: number;
}
